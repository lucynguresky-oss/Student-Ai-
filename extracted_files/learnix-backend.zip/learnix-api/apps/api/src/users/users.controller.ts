import {
  Controller,
  Get,
  Param,
  Post,
  Delete,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import {
  AuthUser,
  CurrentUser,
} from '../common/decorators/current-user.decorator';
import {
  JwtAuthGuard,
  OptionalJwtAuthGuard,
} from '../auth/guards/jwt-auth.guard';
import { UsersService } from './users.service';

@ApiTags('users')
@Controller('users')
export class UsersController {
  constructor(private readonly users: UsersService) {}

  @Get(':username')
  @UseGuards(OptionalJwtAuthGuard)
  getProfile(
    @Param('username') username: string,
    @CurrentUser() viewer?: AuthUser,
  ) {
    return this.users.getProfile(username, viewer?.id);
  }

  @Get(':username/followers')
  @UseGuards(OptionalJwtAuthGuard)
  followers(
    @Param('username') username: string,
    @CurrentUser() viewer?: AuthUser,
  ) {
    return this.users.listFollowers(username, viewer?.id);
  }

  @Get(':username/following')
  @UseGuards(OptionalJwtAuthGuard)
  following(
    @Param('username') username: string,
    @CurrentUser() viewer?: AuthUser,
  ) {
    return this.users.listFollowing(username, viewer?.id);
  }

  @Post(':username/follow')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  follow(@Param('username') username: string, @CurrentUser() user: AuthUser) {
    return this.users.follow(user.id, username);
  }

  @Delete(':username/follow')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  unfollow(@Param('username') username: string, @CurrentUser() user: AuthUser) {
    return this.users.unfollow(user.id, username);
  }

  @Post(':username/accept')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  accept(@Param('username') username: string, @CurrentUser() user: AuthUser) {
    return this.users.acceptRequest(user.id, username);
  }
}
